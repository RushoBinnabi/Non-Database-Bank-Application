/**
 * Provides example implementations (which do not use any database) for banks.
 */
package bank.nodb;